Various bindings to other programming languages.
Typically these are wrapping the [C-binding](../include/led-matrix-c.h) that
comes with rpi-rgb-led-matrix